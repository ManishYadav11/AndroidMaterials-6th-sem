package com.myapp.alarm

import android.annotation.SuppressLint
import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText

class MainActivity : AppCompatActivity() {
    @SuppressLint("MissingInflatedId", "ServiceCast")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val alarmManager = getSystemService(Context.ALARM_SERVICE) as AlarmManager


        val editText :EditText = findViewById(R.id.text)
        val btn : Button = findViewById(R.id.btn)

        btn.setOnClickListener {
            val t = editText.text.toString().toLong()
            val triggeredtime = System.currentTimeMillis() + (t*1000)
            val it = Intent(this , RecieverAcitvity::class.java)

            val pendingIntent = PendingIntent.getBroadcast(
                this,
                0,
                it,
                PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
            )

            alarmManager.set(AlarmManager.RTC_WAKEUP , triggeredtime , pendingIntent)
        }


    }
}