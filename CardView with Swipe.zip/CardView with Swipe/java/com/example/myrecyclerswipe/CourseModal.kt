package com.example.myrecyclerswipe

data class CourseModal (
        // on below line we are creating a
        // two variable one for course
        // name and other for course image
        var courseName: String,
        var courseImg: Int
)