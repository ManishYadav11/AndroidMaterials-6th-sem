package com.myapp.dynamicfragment

import android.os.Bundle
import android.widget.Button
import androidx.appcompat.app.AppCompatActivity
import androidx.fragment.app.Fragment
import androidx.fragment.app.FragmentManager
import androidx.fragment.app.FragmentTransaction

class MainActivity : AppCompatActivity() {

    lateinit var btnA: Button
    lateinit var btnB: Button
    lateinit var btnC: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        btnA = findViewById(R.id.btnA)
        btnB = findViewById(R.id.btnB)
        btnC = findViewById(R.id.btnC)

        btnA.setOnClickListener {
            loadFragment(AFragment()) // Load FragmentA when btnA is clicked
        }

        btnB.setOnClickListener {
            loadFragment(BFragment()) // Load FragmentB when btnB is clicked
        }

        btnC.setOnClickListener {
            loadFragment(CFragment()) // Load FragmentC when btnC is clicked
        }
    }

    // Define loadFragment function outside onCreate method
    private fun loadFragment(fragment: Fragment) {
        val fm: FragmentManager = supportFragmentManager
        val ft: FragmentTransaction = fm.beginTransaction()

        ft.replace(R.id.container, fragment) // Replace the current fragment with the new one
        ft.addToBackStack(null) // Optional: Add the transaction to the back stack
        ft.commit()
    }
}
