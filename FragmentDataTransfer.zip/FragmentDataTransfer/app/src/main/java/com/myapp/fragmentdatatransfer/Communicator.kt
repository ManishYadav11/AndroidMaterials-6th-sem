package com.myapp.fragmentdatatransfer

interface Communicator {
    fun passData(editTextArgs: String)
}