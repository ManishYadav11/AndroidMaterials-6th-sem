package com.myapp.fragmentdatatransfer

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle

class MainActivity : AppCompatActivity(),Communicator {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val uf = UpperFragment()
        supportFragmentManager.beginTransaction().replace(R.id.fc,uf)
    }

    override fun passData(editTextArgs: String) {
        val bundle= Bundle()
        bundle.putString("message", editTextArgs)
        val transaction = this.supportFragmentManager.beginTransaction()
        val fragment1= LowerFragment()
        fragment1.arguments =bundle
        transaction.replace(R.id.fc, fragment1).commit()
    }
}