package com.myapp.sharedpreferences

import android.annotation.SuppressLint
import android.content.Context
import android.content.SharedPreferences
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.EditText
import android.widget.TextView

class MainActivity : AppCompatActivity() {

    lateinit var sharedPreference : SharedPreferences
    lateinit var  name : TextView
    lateinit var email : TextView
    val myPreferences = "mypref"
     val Name = "namekey"
     val Email = "emailkey"
    @SuppressLint("MissingInflatedId")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

    }
    fun save(view : View){

        name = findViewById(R.id.name)
        email = findViewById(R.id.email)

        sharedPreference = getSharedPreferences(myPreferences , Context.MODE_PRIVATE)
        val n = name.text.toString()
        val e = email.text.toString()
        val editor = sharedPreference.edit()
        editor.putString(Name , n)
        editor.putString(Email , e)
        editor.apply()
    }

    fun clear (view : View?) {
        name.text = ""
        email.text = ""
    }

    fun getVal(view : View){
        sharedPreference = getSharedPreferences(myPreferences , Context.MODE_PRIVATE)
        name.text = sharedPreference.getString(Name , "")
        email.text = sharedPreference.getString(Email , "")

    }
}