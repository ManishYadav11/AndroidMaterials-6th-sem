package com.myapp.testfooter

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.Gravity
import android.view.LayoutInflater
import android.view.Menu
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.Toast
import com.google.android.material.bottomnavigation.BottomNavigationView
import com.myapp.testfooter.R.id.button

private lateinit var  nv : BottomNavigationView

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val btn : Button = findViewById(R.id.button)

        btn.setOnClickListener {
            val inflater = layoutInflater
            val layout : View = inflater.inflate(R.layout.custom_toast, findViewById(R.id.my_viewgrp))

            val toast = Toast(applicationContext)
            toast.setGravity(Gravity.CENTER_VERTICAL, 0, 0)
            toast.duration = Toast.LENGTH_LONG
            toast.view = layout
            toast.show()
        }

        nv = findViewById(R.id.nav)

        nv.setOnItemSelectedListener { menuItem ->

            when (menuItem.itemId) {
                R.id.item1 -> {
                    Toast.makeText(this, "Search is working", Toast.LENGTH_LONG).show()
                    true
                }

                R.id.item2 -> {
                    Toast.makeText(this, "Search is working", Toast.LENGTH_LONG).show()
                    true
                }

                R.id.item3 -> {
                    Toast.makeText(this, "Setting is working", Toast.LENGTH_LONG).show()
                    true
                }

                R.id.item4 -> {
                    finish()
                    Toast.makeText(this, "Exit is working", Toast.LENGTH_LONG).show()
                    true
                }

                else -> {
                    false
                }
            }

        }
    }







}