package com.myapp.textscrollview

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.RatingBar
import android.widget.TextView
import android.widget.Toast

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val btn : Button =findViewById(R.id.btn1);
        btn.setOnClickListener {
            Toast.makeText(this , "Btn1 clicked" , Toast.LENGTH_LONG).show();
        }

        // for rating bar

        val rat1 : RatingBar = findViewById(R.id.rb1)
        val rat2 : RatingBar = findViewById(R.id.rb2)
        val rateT :TextView= findViewById(R.id.text)
        val button : Button = findViewById(R.id.subbtn)

        button.setOnClickListener(){
            var rating1 = "Rating ::" + rat1.rating
            var r1 = rat1.rating
            var r2 = rat2.rating
            var avg = (r1 + r2) / 2;
            rat1.rating = avg

            when(avg.toInt()){
                5 -> {
                    rateT.setText("best")
                }
                4 ->{
                    rateT.setText("good")
                }
                3 -> {
                    rateT.setText("average")
                }
                2 ->{
                    rateT.setText("bad")
                }
                else ->
                    rateT.setText("worst")
            }
        }

    }
}